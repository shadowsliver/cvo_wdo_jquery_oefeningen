
0.3.2 / 2014-05-29 
==================

  * Updated smooth scroller

0.3.1 / 2014-05-23 
==================

  * Updated smooth scroller


0.3.0 / 2014-05-20 
==================

  * Allows configuring of activeClass
  * Verbose IDs
  * Added ability to override smooth scroll.
  * Doesn't render span if header has id.
  * Uses id on element if exists.
  * Added smooth-scroller plugin support.
  * updated doc urls

0.2.0 / 2014-04-06 
==================

  * added option for scrollToOffset
  * do not highlight when scrolling because of click
  * select the closest header
  * fix if multiple tocs on the page
  * fixed jquery src on example
  * updated build scripts and dep versions
  * updated build scripts to use load-grunt-config
  * Merge pull request #31 from inadarei/master
  * Support using ordered lists, not just unordered one, for TOC
  * Supporting usage of ordered lists, not just unordered ones.
  * Merge pull request #28 from jgallen23/feature/tests
  * Added some tests.
  * updated bower to include jquery as a dependency
  * updated grunt tasks

0.1.2 / 2013-04-08 
==================

  * optimized scroll function.  fixes #15
  * migrated to grunt for building
  * fixed tabs on docs/index

0.1.1 / 2012-10-05 
==================

  * updated example
  * code cleanup, fixed onHighlight, removed console.log
  * Add headerText and itemClass options

0.1.0 / 2012-07-05 
==================

  * added smoosh to Makefile
  * updated docs
  * removed site submodule
  * Added callback for when a new section is highlighted
  * selected event
  * adds another option to customize the header link text
  * updated site

0.0.3 / 2012-04-06 
==================

  * fixed smooth scrolling in firefox
  * fixed copyright typo

0.0.2 / 2012-03-09
==================

  * Issue [#2](https://github.com/jgallen23/toc/issues/2 "Issue #2")
  * updated site
  * 0.0.2 - updated docs

0.0.1 / 2012-02-25 
==================

  * updated docs/site
  * added readme
  * got everything working
  * initial commit
