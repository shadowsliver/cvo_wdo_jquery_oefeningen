#TOC

[TOC](http://projects.jga.me/toc/) is a jQuery plugin for automatically generating a table of contents. 

For more information, check out the [documentation](http://projects.jga.me/toc/).
